<?php echo View::make("layout.header"); ?>
  <?php echo View::make("layout.topmenu"); ?>
  <div class="page-container row-fluid">
      <?php echo View::make("layout.navigation"); ?>
    <div class="page-content">
        This page will display big sized menus
    </div>
  </div>
<?php echo View::make("layout.footer"); ?>