<script type="text/javascript" src="js/app/dashboardcontroller.js"></script>
<style type="text/css">
	.my-table thead {
		background-color: #EBEBEB;
	}
</style>

<div class='container-fluid' ng-controller="DashboardController">
	
</div>