<?php

class Template_Named_Controller extends Controller {

	public $layout = 'name: home';

	public function action_index()
	{
		//
	}

}