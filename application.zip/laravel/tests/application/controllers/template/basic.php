<?php

class Template_Basic_Controller extends Controller {

	public $layout = 'home.index';

	public function action_index()
	{
		//
	}

}