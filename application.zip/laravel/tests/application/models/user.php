<?php

class User {}